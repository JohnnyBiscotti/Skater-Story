# Print title
print ("> Skater Story! <")

# Figuring out how users might respond
answer_A = ["A", "a"]
answer_B = ["B", "b"]
answer_C = ["C", "c"]
yes = ["Y", "y", "yes"]
no = ["N", "n", "no"]

def main():

	print ("""
	Welcome! Let's start the adventure.
	You are lying on the couch when you get the sudden urge to learn to skateboard.
	Will you:
	""")
	print ("""	A. Play a skateboarding video game
	B. Skateboard Outside
	C. Resist the urge & continue to lie down""")

	ans1 = input(">> ")


	if ans1 in answer_A:
		print ("\nIts time to go to bed."
		" Would you like to stay up and practice? (Yes / No)")
		
		ans2 = input(">> ")
		if ans2 in yes:
			print("\nYou Lose"
				"\nWould you like to play again? (Yes / No)")
			ans4 = input(">> ")
			if ans4 in yes:
				main()
			else:
				exit()	
		elif ans2 in no:
			print ("\nYou Lose"
				"\nWould you like to play again? (Yes / No)")
			ans4 = input(">> ")
			if ans4 in yes:
				main()
			else:
				exit()	
		else:
			print ("\nYou typed the wrong input. Goodbye.")


	elif ans1 in answer_B:
		print ("\nYou fall down when your first learning to ride on a skateboard."
			" Would you like to go back inside? (Yes / No)")

		ans3 = input(">> ")
		if ans3 in yes:
			print("\nYou Lose.")
		elif ans3 in no:
			print ("\nYOU WIN!!"
				" Congratulations you have what it takes to be a skateboarder!"
				" Thanks for Playing & Enjoy the Sun."
				"\nWould you like to play again? (Yes / No)")
			ans4 = input(">> ")
			if ans4 in yes:
				main()
			else:
				exit()	
		else:
			print ("\nYou typed the wrong input. Goodbye.")


	elif ans1 in answer_C:
		print ("\nYou Lose")
		# Print title
print ("> Skater Story! <")

# Figuring out how users might respond
answer_A = ["A", "a"]
answer_B = ["B", "b"]
answer_C = ["C", "c"]
yes = ["Y", "y", "yes"]
no = ["N", "n", "no"]

def main():

	print ("""
	Welcome! Let's start the adventure.
	You are lying on the couch when you get the sudden urge to learn to skateboard.
	Will you:
	""")
	print ("""	A. Play a skateboarding video game
	B. Skateboard Outside
	C. Resist the urge & continue to lie down""")

	ans1 = input(">> ")


	if ans1 in answer_A:
		print ("\nIts time to go to bed."
		" Would you like to stay up and practice? (Yes / No)")
		
		ans2 = input(">> ")
		if ans2 in yes:
			print("\nYou Lose"
				"\nWould you like to play again? (Yes / No)")
			ans4 = input(">> ")
			if ans4 in yes:
				main()
			else:
				exit()	
		elif ans2 in no:
			print ("\nYou Lose"
				"\nWould you like to play again? (Yes / No)")
			ans4 = input(">> ")
			if ans4 in yes:
				main()
			else:
				exit()	
		else:
			print ("\nYou typed the wrong input. Goodbye.")


	elif ans1 in answer_B:
		print ("\nYou fall down when your first learning to ride on a skateboard."
			" Would you like to go back inside? (Yes / No)")

		ans3 = input(">> ")
		if ans3 in yes:
			print("\nYou Lose."
								"\nWould you like to play again? (Yes / No)")
			ans4 = input(">> ")
			if ans4 in yes:
				main()
			else:
				exit()	
		elif ans3 in no:
			print ("\nYOU WIN!!"
				" Congratulations you have what it takes to be a skateboarder!"
				" Thanks for Playing & Enjoy the Sun."
				"\nWould you like to play again? (Yes / No)")
			ans4 = input(">> ")
			if ans4 in yes:
				main()
			else:
				exit()	
		else:
			print ("\nYou typed the wrong input. Goodbye.")


	elif ans1 in answer_C:
		print ("\nYou Lose"
				"\nWould you like to play again? (Yes / No)")
		ans4 = input(">> ")
		if ans4 in yes:
			main()
		else:
			exit()	
	else:
		print ("\nYou typed the wrong input. Goodbye.")
main()